# Muck x Left 4 Dead 2 — local asset bridge, milestone 0.1

**This is a source-code prototype, not a completed playable mashup.** It has not been compiled or tested against the user's Muck/L4D2 installations. No Valve audio, image, model, or game binaries are included.

## Implemented now
- BepInEx plugin shell for Muck (Unity Mono).
- Eight local survivor selections saved separately on each client's machine. Duplicates permitted in UI, **not yet replicated to peers**.
- Attempts to discover L4D2 from common Windows Steam folders or an explicit path in the generated BepInEx config.
- Indexes installed VPK v1/v2 archives, and reads assets into memory without extracting files or bundling assets.
- Survivor voice and weapon WAV discovery plus F7/F8 **random preview**, using PCM / IEEE-float WAV decode. Many Source WAV sounds are ADPCM/other codecs and will not preview until decoding is extended.
- F6 toggles a simple survivor selection menu.

## Not implemented yet
- L4D2 portrait VTF loading and portrait replacement in Muck's UI.
- Automatic survivor voice events and weapon-sound replacement hooks.
- Multiplayer survivor replication and per-peer playback.
- Character models, first-person viewmodels, animations, L4D2 movement, crouch/shove, weapon recoil, weapons, item crafting/chest pools, Tank/Hunter boss events.

These are deliberately excluded rather than falsely presented as working. Muck's mining, crafting, physics, combat, and co-op are left untouched by this prototype.

## Compile and install (Windows, PowerShell)
1. Install both games through Steam. Install [BepInExPack Muck](https://thunderstore.io/c/muck/p/BepInEx/BepInExPack_Muck/) and launch Muck once.
2. Install the .NET SDK and the .NET Framework 4.8 developer targeting pack if the compiler asks for it.
3. Open PowerShell **inside this source folder** and run:

```powershell
.\build.ps1 -MuckDir "C:\Program Files (x86)\Steam\steamapps\common\Muck"
```

4. Launch Muck; press **F6** for the character menu, **F7** for random survivor voice preview, **F8** for random weapon sound preview.
5. If L4D2 is installed on another drive, edit:
`Muck\BepInEx\config\community.muck.l4d2bridge.cfg`
under `[Assets]` and set `L4D2Path = D:\SteamLibrary\steamapps\common\Left 4 Dead 2` (use your real path). Restart Muck.
6. Troubleshooting: `Muck\BepInEx\LogOutput.log`. Sound preview may fail if a WAV uses Source ADPCM rather than PCM.

## Planned milestones
1. Complete runtime codec support, VTF portrait decoder and event/sound hooks; verify the voices from all eight survivors.
2. Render models and viewmodels from local Source formats through a runtime adapter (or separately user-generated conversion cache if explicit consent is added; current mode never copies/extracts files).
3. Tank boss event on Muck's own boss spawner.
4. Hunter boss event. No common infected.
5. Integrate L4D2 movement/weapons/items while preserving Muck resource and roguelite progression. Add co-op state sync through Muck networking.

## Licensing and redistribution
The **original bridge code** is offered under CC BY 4.0 (see LICENSE). This does not relicense Valve's Left 4 Dead 2 assets or Muck. Players must separately own/install those games. Sharing or remixing this bridge's original code is permitted with attribution, but redistributing Valve game content requires separate permission; simply having a CC BY mod license does not grant that permission.

## Engineering limitations
- `.vpk` is a Valve archive; Unity does not directly import Source `.mdl` or `.vtf` formats.
- Selected local character currently changes only the voice-preview source; it does not alter the Muck player mesh/network identity.
- Sampled preview tries a small number of random tracks and may report unsupported codecs even if other tracks would work.
- Do not ship copies of game assets, pre-converted models, sounds, textures, or game assemblies inside a mod package.
