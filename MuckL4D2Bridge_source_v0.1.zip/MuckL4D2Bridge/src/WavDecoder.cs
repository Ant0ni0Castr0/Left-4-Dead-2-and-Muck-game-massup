using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace MuckL4D2Bridge {
    internal static class WavDecoder {
        // In-memory PCM / IEEE float WAV only. Source ADPCM/MP3 WAV files are explicitly not supported yet.
        internal static AudioClip Decode(byte[] bytes, string name) {
            if (bytes == null || bytes.Length < 44) return null;
            using (var m = new MemoryStream(bytes)) using (var b = new BinaryReader(m)) {
                if (Encoding.ASCII.GetString(b.ReadBytes(4)) != "RIFF") return null;
                b.ReadUInt32(); if (Encoding.ASCII.GetString(b.ReadBytes(4)) != "WAVE") return null;
                ushort format=0, channels=0, bits=0; uint rate=0; long start=0; int length=0;
                while (m.Position + 8 <= m.Length) {
                    string chunk = Encoding.ASCII.GetString(b.ReadBytes(4)); uint size = b.ReadUInt32();
                    long next = m.Position + size; if (next > m.Length) return null;
                    if (chunk == "fmt " && size >= 16) { format=b.ReadUInt16(); channels=b.ReadUInt16(); rate=b.ReadUInt32(); b.ReadUInt32(); b.ReadUInt16(); bits=b.ReadUInt16(); }
                    else if (chunk == "data") { start=m.Position; length=(int)size; }
                    m.Position = next + (size & 1); 
                }
                if ((format != 1 && format != 3) || channels < 1 || channels > 2 || rate == 0 || rate > 192000) return null;
                if (!((format == 1 && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) || (format == 3 && bits == 32))) return null;
                int count=length/(bits/8); if (count == 0 || count % channels != 0) return null;
                float[] samples = new float[count]; m.Position=start;
                for (int i=0; i<count; i++) {
                    if (format == 3) samples[i] = b.ReadSingle();
                    else if (bits == 8) samples[i] = (b.ReadByte()-128)/128f;
                    else if (bits == 16) samples[i] = b.ReadInt16()/32768f;
                    else if (bits == 24) { int v=b.ReadByte() | (b.ReadByte()<<8) | (b.ReadByte()<<16); if ((v & 0x800000)!=0) v |= unchecked((int)0xff000000); samples[i] = v/8388608f; }
                    else samples[i] = b.ReadInt32()/2147483648f;
                }
                var clip=AudioClip.Create(name, count/channels, channels, (int)rate, false);
                clip.SetData(samples, 0); return clip;
            }
        }
    }
}
