namespace MuckL4D2Bridge {
    internal static class Survivors {
        internal static readonly string[] Names = {"Coach", "Ellis", "Nick", "Rochelle", "Bill", "Francis", "Louis", "Zoey"};
        internal static readonly string[] VoiceFolders = {"coach", "mechanic", "gambler", "producer", "namvet", "biker", "manager", "teengirl"};
        internal static readonly string[] ModelFolders = {"coach", "mechanic", "gambler", "producer", "namvet", "biker", "manager", "teenangst"};
    }
}
