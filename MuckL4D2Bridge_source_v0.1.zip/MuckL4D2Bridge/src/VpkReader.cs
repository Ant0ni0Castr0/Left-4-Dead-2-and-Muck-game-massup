using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MuckL4D2Bridge {
    // Reads Valve VPK v1/v2 file trees and streams bytes from the install on demand.
    // No archive or asset is extracted to disk or distributed.
    internal sealed class VpkReader {
        private struct Entry {
            public ushort Archive; public uint Offset, Length;
            public byte[] Preload;
        }
        private readonly Dictionary<string, Entry> entries = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
        private readonly string prefix;
        private readonly long dataStart;
        private readonly string directoryFile;
        internal IEnumerable<string> Paths { get { return entries.Keys; } }
        internal VpkReader(string path) {
            directoryFile = path;
            prefix = path.Substring(0, path.Length - "_dir.vpk".Length);
            using (var fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var r = new BinaryReader(fs)) {
                if (r.ReadUInt32() != 0x55aa1234) throw new InvalidDataException("Not a VPK");
                uint version = r.ReadUInt32();
                uint treeSize = r.ReadUInt32();
                if (version == 2) { r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); }
                else if (version != 1) throw new InvalidDataException("Unsupported VPK version: " + version);
                long treeStart = fs.Position;
                dataStart = treeStart + treeSize;
                while (true) {
                    string ext = ReadZ(r); if (ext.Length == 0) break;
                    while (true) {
                        string dir = ReadZ(r); if (dir.Length == 0) break;
                        while (true) {
                            string name = ReadZ(r); if (name.Length == 0) break;
                            r.ReadUInt32(); // CRC
                            ushort preloadLength = r.ReadUInt16();
                            ushort archive = r.ReadUInt16();
                            uint offset = r.ReadUInt32();
                            uint length = r.ReadUInt32();
                            if (r.ReadUInt16() != 0xffff) throw new InvalidDataException("Invalid VPK entry");
                            byte[] preload = r.ReadBytes(preloadLength);
                            string full = (dir == " " ? "" : dir + "/") + name + "." + ext;
                            entries[full.Replace('\\','/')] = new Entry { Archive=archive, Offset=offset, Length=length, Preload=preload };
                        }
                    }
                }
            }
        }
        private static string ReadZ(BinaryReader reader) {
            var bytes = new List<byte>(); byte c;
            while ((c = reader.ReadByte()) != 0) { if (bytes.Count > 4096) throw new InvalidDataException("Bad VPK string"); bytes.Add(c); }
            return Encoding.UTF8.GetString(bytes.ToArray());
        }
        internal byte[] Read(string path) {
            Entry entry;
            if (!entries.TryGetValue(path.Replace('\\','/'), out entry)) return null;
            if (entry.Length > 33554432) throw new InvalidDataException("Asset too large");
            byte[] result = new byte[entry.Preload.Length + (int)entry.Length];
            Buffer.BlockCopy(entry.Preload, 0, result, 0, entry.Preload.Length);
            if (entry.Length == 0) return result;
            string file = entry.Archive == 0x7fff ? directoryFile : prefix + "_" + entry.Archive.ToString("D3") + ".vpk";
            using (var fs = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)) {
                long absolute = (entry.Archive == 0x7fff ? dataStart : 0) + entry.Offset;
                fs.Seek(absolute, SeekOrigin.Begin);
                int position = entry.Preload.Length;
                while (position < result.Length) {
                    int read = fs.Read(result, position, result.Length - position);
                    if (read == 0) throw new EndOfStreamException(file);
                    position += read;
                }
            }
            return result;
        }
    }
}
