using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;

namespace MuckL4D2Bridge {
    [BepInPlugin("community.muck.l4d2bridge", "Muck x L4D2 Bridge", "0.1.0")]
    public sealed class Plugin : BaseUnityPlugin {
        private ConfigEntry<string> installedPath;
        private ConfigEntry<int> selection;
        private readonly List<VpkReader> archives = new List<VpkReader>();
        private readonly Dictionary<int, List<string>> voices = new Dictionary<int, List<string>>();
        private readonly List<string> weaponSounds = new List<string>();
        private AudioSource audioSource;
        private bool showMenu = true;
        private string status = "Starting";
        private System.Random random = new System.Random();
        private void Awake() {
            installedPath = Config.Bind("Assets", "L4D2Path", "", "Full path to Steam's Left 4 Dead 2 game directory (optional). No asset files are copied.");
            selection = Config.Bind("Player", "Survivor", 0, "Local survivor index 0..7. Only saved locally; networking is not yet implemented.");
            var obj = new GameObject("MuckL4D2Bridge_Audio"); DontDestroyOnLoad(obj);
            audioSource=obj.AddComponent<AudioSource>(); audioSource.playOnAwake=false;
            LoadAssets();
        }
        private static string FindInstall(string configured) {
            if (!string.IsNullOrWhiteSpace(configured) && Directory.Exists(configured)) return configured;
            string[] roots = {
                @"C:\Program Files (x86)\Steam\steamapps\common\Left 4 Dead 2",
                @"C:\Program Files\Steam\steamapps\common\Left 4 Dead 2",
                @"D:\SteamLibrary\steamapps\common\Left 4 Dead 2",
                @"D:\Steam\steamapps\common\Left 4 Dead 2",
                @"E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
            };
            foreach (string root in roots) if (Directory.Exists(root)) return root;
            return null;
        }
        private void LoadAssets() {
            archives.Clear(); voices.Clear(); weaponSounds.Clear();
            string root = FindInstall(installedPath.Value);
            if (root == null) { status = "L4D2 not found. Set Assets.L4D2Path in the BepInEx config."; return; }
            foreach (string folder in new[] {"left4dead2", "left4dead2_dlc1", "left4dead2_dlc2", "left4dead2_dlc3", "left4dead2_dlc4", "left4dead2_dlc5"}) {
                string dir=Path.Combine(root, folder);
                if (!Directory.Exists(dir)) continue;
                foreach (string vpk in Directory.GetFiles(dir, "*_dir.vpk", SearchOption.TopDirectoryOnly)) {
                    try { archives.Add(new VpkReader(vpk)); } catch (Exception ex) { Logger.LogWarning("Skipping " + vpk + ": " + ex.Message); }
                }
            }
            if (archives.Count == 0) { status="No VPK directory archives found under " + root; return; }
            // Last mounted archive has priority when games ship updated voice assets.
            var all = archives.SelectMany(v => v.Paths).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            for (int i=0; i<8; i++) {
                string token="/player/survivor/voice/"+Survivors.VoiceFolders[i]+"/";
                voices[i]=all.Where(p => p.StartsWith("sound/", StringComparison.OrdinalIgnoreCase) &&
                    p.Replace('\\','/').IndexOf(token, StringComparison.OrdinalIgnoreCase)>=0 &&
                    p.EndsWith(".wav", StringComparison.OrdinalIgnoreCase)).ToList();
            }
            weaponSounds.AddRange(all.Where(p=>p.StartsWith("sound/weapons/",StringComparison.OrdinalIgnoreCase) && p.EndsWith(".wav",StringComparison.OrdinalIgnoreCase)));
            status="Mounted " + archives.Count + " VPK indexes; " + voices.Sum(kv=>kv.Value.Count) + " voice paths; " + weaponSounds.Count + " weapon WAV paths";
            Logger.LogInfo(status);
        }
        private byte[] ReadAsset(string path) {
            for (int i=archives.Count-1; i>=0; i--) {
                try { byte[] data=archives[i].Read(path); if (data!=null) return data; }
                catch (Exception ex) { Logger.LogWarning("Read failed " + path + ": " + ex.Message); }
            }
            return null;
        }
        private void Preview(IList<string> paths) {
            if (paths==null || paths.Count==0) { status="No matching sound paths found"; return; }
            for (int attempt=0; attempt<Math.Min(12, paths.Count); attempt++) {
                string path=paths[random.Next(paths.Count)];
                AudioClip clip=null;
                try { clip=WavDecoder.Decode(ReadAsset(path),path); } catch(Exception ex) { Logger.LogWarning(ex.Message); }
                if (clip==null) continue;
                audioSource.Stop(); audioSource.clip=clip; audioSource.Play();
                status="Playing: "+path; return;
            }
            status="No playable PCM WAV in random sample (Source ADPCM requires a future decoder)";
        }
        private void Update() {
            if (Input.GetKeyDown(KeyCode.F6)) showMenu=!showMenu;
            if (Input.GetKeyDown(KeyCode.F7)) Preview(voices.ContainsKey(selection.Value) ? voices[selection.Value] : null);
            if (Input.GetKeyDown(KeyCode.F8)) Preview(weaponSounds);
        }
        private void OnGUI() {
            if (!showMenu) return;
            GUILayout.BeginArea(new Rect(15, 15, 410, 320), GUI.skin.box);
            GUILayout.Label("Muck x Left 4 Dead 2 | Asset bridge v0.1");
            GUILayout.Label("Local survivor (duplicates permitted):");
            for (int row=0; row<2; row++) {
                GUILayout.BeginHorizontal();
                for (int col=0; col<4; col++) {
                    int i=row*4+col;
                    if (GUILayout.Button((selection.Value==i ? "[" : "") + Survivors.Names[i] + (selection.Value==i ? "]" : ""))) selection.Value=i;
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.Space(8);
            if (GUILayout.Button("Preview my survivor voice (F7)")) Preview(voices.ContainsKey(selection.Value) ? voices[selection.Value] : null);
            if (GUILayout.Button("Preview weapon sound (F8)")) Preview(weaponSounds);
            if (GUILayout.Button("Reload local indexes")) LoadAssets();
            GUILayout.Label("F6: show/hide | F7: voice | F8: weapon");
            GUILayout.Label("Status: " + status);
            GUILayout.Label("Prototype: previews only; no gameplay or network patches yet.");
            GUILayout.EndArea();
        }
    }
}
