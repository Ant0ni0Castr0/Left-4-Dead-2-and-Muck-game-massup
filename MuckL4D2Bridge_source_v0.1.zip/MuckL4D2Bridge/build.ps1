param([Parameter(Mandatory=$true)][string]$MuckDir)
$ErrorActionPreference = 'Stop'
if (!(Test-Path "$MuckDir\Muck_Data\Managed\UnityEngine.CoreModule.dll")) { throw "MuckDir must be your Muck installation folder" }
dotnet build .\MuckL4D2Bridge.csproj -c Release -p:MuckDir="$MuckDir"
if ($LASTEXITCODE -ne 0) { throw "Build failed" }
New-Item -ItemType Directory -Force "$MuckDir\BepInEx\plugins" | Out-Null
Copy-Item .\bin\Release\net48\MuckL4D2Bridge.dll "$MuckDir\BepInEx\plugins\" -Force
Write-Host 'Installed MuckL4D2Bridge.dll. Launch Muck; press F6.'
